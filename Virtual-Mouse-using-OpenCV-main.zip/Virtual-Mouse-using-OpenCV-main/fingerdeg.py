import cv2
import mediapipe as mp
import numpy as np
import math
import pyautogui
mp_hands = mp.solutions.hands
mp_drawing = mp.solutions.drawing_utils
pyautogui.FAILSAFE = False

# Set up the video capture
cap = cv2.VideoCapture(0)

screen_width, screen_height = pyautogui.size()

with mp_hands.Hands(
        min_detection_confidence=0.5,
        min_tracking_confidence=0.5) as hands:

    while cap.isOpened():
        success, image = cap.read()
        if not success:
            print("Ignoring empty camera frame.")
            continue

        # Flip the image horizontally for a later selfie-view display
        image = cv2.flip(image, 1)

        # Convert the image color from BGR to RGB before processing
        image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)

        # Process the image with MediaPipe Hands
        results = hands.process(image)

        # Draw landmarks and connections on the image
        image.flags.writeable = True
        image = cv2.cvtColor(image, cv2.COLOR_RGB2BGR)
        if results.multi_hand_landmarks:
            for hand_landmarks in results.multi_hand_landmarks:
                mp_drawing.draw_landmarks(
                    image, hand_landmarks, mp_hands.HAND_CONNECTIONS)

                # Get the coordinates of each finger tip
                thumb_tip = hand_landmarks.landmark[mp_hands.HandLandmark.THUMB_TIP]
                index_tip = hand_landmarks.landmark[mp_hands.HandLandmark.INDEX_FINGER_TIP]
                middle_tip = hand_landmarks.landmark[mp_hands.HandLandmark.MIDDLE_FINGER_TIP]
                ring_tip = hand_landmarks.landmark[mp_hands.HandLandmark.RING_FINGER_TIP]
                pinky_tip = hand_landmarks.landmark[mp_hands.HandLandmark.PINKY_TIP]

                # Calculate the Euclidean distances between each finger tip and thumb tip
                thumb_index_distance = math.sqrt((thumb_tip.x - index_tip.x) ** 2 + (thumb_tip.y - index_tip.y) ** 2 + (thumb_tip.z - index_tip.z) ** 2)
                thumb_middle_distance = math.sqrt((thumb_tip.x - middle_tip.x) ** 2 + (thumb_tip.y - middle_tip.y) ** 2 + (thumb_tip.z - middle_tip.z) ** 2)
                thumb_ring_distance = math.sqrt((thumb_tip.x - ring_tip.x) ** 2 + (thumb_tip.y - ring_tip.y) ** 2 + (thumb_tip.z - ring_tip.z) ** 2)
                thumb_pinky_distance = math.sqrt((thumb_tip.x - pinky_tip.x) ** 2 + (thumb_tip.y - pinky_tip.y) ** 2 + (thumb_tip.z - pinky_tip.z) ** 2)

                # Set up the thresholds for pinch detection
                pinch_threshold = 0.05
                pinch_two_fingers = 0.035
                pinch_three_fingers = 0.025
                pinch_four_fingers = 0.02

                # Get the coordinates of the pointer finger tip
                index_tip_x = index_tip.x
                index_tip_y = index_tip.y

                """WIP
                # Check if the pointer finger is almost completely straight up
                if index_tip_x > 0.4 and index_tip_y < 0.5:
                    x3 = np.interp(x1, (frameR,width-frameR), (0,screen_width))
                    y3 = np.interp(y1, (frameR, height-frameR), (0, screen_height))

                    curr_x = prev_x + (x3 - prev_x)/smoothening
                    curr_y = prev_y + (y3 - prev_y) / smoothening

                    pyautogui.move(screen_width - curr_x, curr_y)    # Moving the cursor
                    cv2.circle(img, (x1, y1), 7, (255, 0, 255), cv2.FILLED)
                    prev_x, prev_y = curr_x, curr_y
                Mouse Movement """ 

                # Detect individual finger pinches and label them
                if thumb_index_distance < pinch_threshold:
                    cv2.putText(image, "Thumb-Index Pinch", (50, 50), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)

                if thumb_middle_distance < pinch_threshold:
                    cv2.putText(image, "Thumb-Middle Pinch", (50, 50), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)

                if thumb_ring_distance < pinch_threshold:
                    cv2.putText(image, "Thumb-Ring Pinch", (50, 50), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)

                if thumb_pinky_distance < pinch_threshold:
                    cv2.putText(image, "Thumb-Pinky Pinch", (50, 50), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)

                if thumb_index_distance < pinch_two_fingers and thumb_middle_distance < pinch_two_fingers:
                    cv2.putText(image, "Thumb-Index-Middle Pinch", (50, 50), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)

                if thumb_index_distance < pinch_two_fingers and thumb_ring_distance < pinch_two_fingers:
                    cv2.putText(image, "Thumb-Index-Ring Pinch", (50, 50), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)

                if thumb_index_distance < pinch_two_fingers and thumb_pinky_distance < pinch_two_fingers:
                    cv2.putText(image, "Thumb-Index-Pinky Pinch", (50, 50), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)

                if thumb_middle_distance < pinch_two_fingers and thumb_ring_distance < pinch_two_fingers:
                    cv2.putText(image, "Thumb-Middle-Ring Pinch", (50, 50), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)

                if thumb_middle_distance < pinch_two_fingers and thumb_pinky_distance < pinch_two_fingers:
                    cv2.putText(image, "Thumb-Middle-Pinky Pinch", (50, 50), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)

                if thumb_ring_distance < pinch_two_fingers and thumb_pinky_distance < pinch_two_fingers:
                    cv2.putText(image, "Thumb-Ring-Pinky Pinch", (50, 50), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)

                if thumb_index_distance < pinch_three_fingers and thumb_middle_distance < pinch_three_fingers and thumb_ring_distance < pinch_three_fingers:
                    cv2.putText(image, "Thumb-Index-Middle-Ring Pinch", (50, 50), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)

                if thumb_index_distance < pinch_three_fingers and thumb_middle_distance < pinch_three_fingers and thumb_pinky_distance < pinch_three_fingers:
                    cv2.putText(image, "Thumb-Index-Middle-Pinky Pinch", (50, 50), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)

                if thumb_index_distance < pinch_three_fingers and thumb_ring_distance < pinch_three_fingers and thumb_pinky_distance < pinch_three_fingers:
                    cv2.putText(image, "Thumb-Index-Ring-Pinky Pinch", (50, 50), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)

                if thumb_middle_distance < pinch_three_fingers and thumb_ring_distance < pinch_three_fingers and thumb_pinky_distance < pinch_three_fingers:
                    cv2.putText(image, "Thumb-Middle-Ring-Pinky Pinch", (50, 50), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)

        # Display the resulting image
        cv2.imshow("Hand Tracking", image)

        # Exit if 'q' is pressed
        if cv2.waitKey(1) == ord('q'):
            break

    # Release the webcam and close all windows
    cap.release()
    cv2.destroyAllWindows()

